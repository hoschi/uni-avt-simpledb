package main;

import relationenalgebra.ITreeNode;

public class Main {

//Verzeichnis der Buchversandsdatenbank	
public static final String KUNDENDB = "";

    public static void main(String[] args){
    	//TODO Tests...
    }
		
	public static void printKundenDB(){
		//TODO
	}
	
	public static void createKundenDB(){
		//TODO
	}
	
	public static void execute(String simpleSQL){
	   //TODO Anfrage �bersetzen
	   //TODO Anfrage ausf�hren
	}
	
	public static ITreeNode sqlToRelationenAlgebra(String simpleSQL){
		//TODO default
		return null;
	}
	
	
	private static void executePlan(ITreeNode plan){
		//TODO
	}
		

}
