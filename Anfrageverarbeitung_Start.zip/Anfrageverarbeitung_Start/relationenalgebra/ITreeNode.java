package relationenalgebra;

public interface ITreeNode {

}
